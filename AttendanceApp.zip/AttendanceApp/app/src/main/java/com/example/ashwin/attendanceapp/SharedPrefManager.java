package com.example.ashwin.attendanceapp;

import android.content.Context;
import android.content.SharedPreferences;

public class SharedPrefManager {

    private static final String SHARED_PREF_NAME = "SHARED_PREF";
    private static final String FIRST_NAME = "FIRST_NAME";
    private static final String LAST_NAME = "LAST_NAME";
    private static final String GENDER = "GENDER";
    private static final String TOKEN = "TOKEN";

    private static SharedPrefManager mInstance;
    private static Context mCtx;

    public SharedPrefManager(Context context){
        mCtx = context;

    }

    public static synchronized SharedPrefManager getInstance(Context context){
        if(mInstance==null){
            mInstance = new SharedPrefManager(context);
        }

        return mInstance;

    }

    public boolean saveUserData(String token, String firstname, String lastname, int gender){

        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_NAME,Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(TOKEN,token);
        editor.putString(FIRST_NAME,firstname);
        editor.putString(LAST_NAME,lastname);
        editor.putInt(GENDER,gender);

        editor.apply();

        return true;

    }

}
