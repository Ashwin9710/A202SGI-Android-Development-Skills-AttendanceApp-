package com.example.ashwin.attendanceapp;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.nfc.Tag;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;

import com.cepheuen.elegantnumberbutton.view.ElegantNumberButton;

import java.util.Calendar;

public class SecondPage extends AppCompatActivity {

    Button btn;

    private static final String TAG = "SecondPage";

    private TextView mDisplayDate;
    private DatePickerDialog.OnDateSetListener mDateSetListener;

    private ElegantNumberButton num1;
    private ElegantNumberButton num2;
    private ElegantNumberButton num3;

    private String number1;
    private String number2;
    private String number3;
    private String date;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second_page);

        num1 = (ElegantNumberButton)findViewById(R.id.myButton1);
        num2 = (ElegantNumberButton)findViewById(R.id.myButton2);
        num3 = (ElegantNumberButton)findViewById(R.id.myButton3);

        btn = (Button) findViewById(R.id.button);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                number1 = num1.getNumber();
                number2 = num2.getNumber();
                number3 = num3.getNumber();
                Intent intent = new Intent(SecondPage.this, ThirdPage.class);
                intent.putExtra("first", number1);
                intent.putExtra("second", number2);
                intent.putExtra("third", number3);
                intent.putExtra("date", date);
                startActivity(intent);
                finish();
            }
        });

        mDisplayDate = (TextView) findViewById(R.id.selectdate);
        mDisplayDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar cal = Calendar.getInstance();
                int year = cal.get(Calendar.YEAR);
                int month = cal.get(Calendar.MONTH);
                int day = cal.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog dialog = new DatePickerDialog(SecondPage.this, android.R.style.Theme_Black, mDateSetListener,
                        year,month,day);

                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.show();
            }
        });

        mDateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                month = month + 1;
                Log.d(TAG,"onDateSet: dd/mm/yy: " + dayOfMonth + "/" + month + " / " + year + " / ");

                date = dayOfMonth + " / " + month + " / " + year;
                mDisplayDate.setText(date);
            }
        };


    }

}