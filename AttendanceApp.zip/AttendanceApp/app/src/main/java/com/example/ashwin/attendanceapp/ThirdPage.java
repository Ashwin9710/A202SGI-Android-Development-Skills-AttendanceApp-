package com.example.ashwin.attendanceapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ThirdPage extends AppCompatActivity {

    private String num1;
    private String num2;
    private String num3;
    private String date;

    private TextView resultDisplay;

    private Button sendButton;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third_page);

        sendButton = (Button) findViewById(R.id.sendButton);
        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();

            }
        });

        Intent intent = getIntent();
        num1 = intent.getStringExtra("first");
        num2 = intent.getStringExtra("second");
        num3 = intent.getStringExtra("third");
        date = intent.getStringExtra("date");

        resultDisplay = (TextView)findViewById(R.id.resultTextView);
        resultDisplay.setText("The attendance date : " + date + "\n\nNumber of students (DATABASE) : " + num1 + "\nNumber of students (NETWORKING) : " + num2 + "\nNumber of students (PROGRAMMING) : " + num3);
    }
}
