package com.example.ashwin.attendanceapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.UUID;

import at.markushi.ui.CircleButton;

import static com.example.ashwin.attendanceapp.data.Constants.GENDER_FEMALE;
import static com.example.ashwin.attendanceapp.data.Constants.GENDER_MALE;

public class FirstPage extends AppCompatActivity {

    public CircleButton male;
    public CircleButton female;
    public CircleButton login;


    public EditText firstname;
    public EditText lastname;

    int gender=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first_page);

        male=findViewById(R.id.male);
        female=findViewById(R.id.female);
        firstname=findViewById(R.id.firstname);
        lastname=findViewById(R.id.lastname);
        login=findViewById(R.id.loginButton);

        male.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gender=GENDER_MALE;
                male.setColor(getResources().getColor(R.color.green));
                female.setColor(getResources().getColor(R.color.white));

            }
        });

        female.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gender=GENDER_FEMALE;
                female.setColor(getResources().getColor(R.color.green));
                male.setColor(getResources().getColor(R.color.white));

            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!TextUtils.isEmpty(firstname.getText().toString().trim())&&!TextUtils.isEmpty(lastname.getText().toString().trim())){
                    if(gender==0){
                        Toast.makeText(FirstPage.this, "Please Select Gender", Toast.LENGTH_LONG).show();
                        
                    }
                    else{

                        if (SharedPrefManager.getInstance(getApplicationContext()).
                                saveUserData(UUID.randomUUID().toString(),
                                        firstname.getText().toString().trim(),
                                        lastname.getText().toString().trim(),
                                        gender)){

                            Toast.makeText(FirstPage.this, "Registered Successfully", Toast.LENGTH_LONG).show();

                            Intent intent = new Intent(FirstPage.this,SecondPage.class);
                            startActivity(intent);
                        }
                    }
                }

                else{
                    Toast.makeText(FirstPage.this, "Invalid Name", Toast.LENGTH_LONG).show();

                }
            }

        });




    }
}
