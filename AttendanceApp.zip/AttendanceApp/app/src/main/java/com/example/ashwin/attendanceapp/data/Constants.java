package com.example.ashwin.attendanceapp.data;

public class Constants {

    public static final int GENDER_MALE = 1;
    public static final int GENDER_FEMALE = 2;
}
